#ifndef ThreadedPlayer_H
#define ThreadedPlayer_H
 
#include <QThread>
#include <QTime>
#include "SimpleViewUI.h"
#include <vtkPolyData.h>
#include "vtkTimerLog.h"

// Forward Qt class declarations
//class Ui_SimpleView;
 
class ThreadedPlayer : public QThread
{
  Q_OBJECT/*
public:
 void run();
 ThreadedPlayer();
	void setView(SimpleView *theView);
	void setTimeInterval(double durationBetweenUpdate, int numberOfUpdates);
	double timeInterval;
	int updates;*/
	public:
	ThreadedPlayer();
	void run();
	void setPolyData();
	void setTimeInterval(double durationBetweenUpdate, int numberOfUpdate);
	SimpleView *view;
	double timeInterval;
	int updates;
	bool play;
signals:
	void updateView();
	void doneUpdating();
public slots:
	void slotStopPlaying();
 
};
 
#endif // SimpleViewUI_H