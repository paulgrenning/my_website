#include "ui_SimpleViewUI.h"
#include "SimpleViewUI.h"
#include <vtkPolyDataMapper.h>
#include <vtkSphereSource.h>
#include <vtkSmartPointer.h>
#include <vtkProperty.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkDelimitedTextReader.h>
#include <vtkTable.h>
#include <vtkPointData.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkVertexGlyphFilter.h>
#include "vtkBMPReader.h"
#include "vtkCamera.h"
#include "vtkGeoAlignedImageRepresentation.h"
#include "vtkGeoAlignedImageSource.h"
#include "vtkGeoEdgeStrategy.h"
#include "vtkGeoFileImageSource.h"
#include "vtkGeoFileTerrainSource.h"
#include "vtkGeoGlobeSource.h"
#include "vtkGeoProjection.h"
#include "vtkGeoProjectionSource.h"
#include "vtkGeoRandomGraphSource.h"
#include "vtkGeoSphereTransform.h"
#include "vtkGeoTerrain.h"
#include "vtkGeoTerrainNode.h"
#include "vtkGeoTerrain2D.h"
#include "vtkGeoTransform.h"
#include "vtkGeoView.h"
#include "vtkGeoView2D.h"
#include "vtkGraphLayoutView.h"
#include "vtkJPEGReader.h"
#include "vtkRegressionTestImage.h"
#include "vtkRenderedGraphRepresentation.h"
#include "vtkRenderer.h"
#include "vtkRenderWindow.h"
#include "vtkStdString.h"
#include "vtkTestUtilities.h"
#include "vtkTIFFReader.h"
#include "vtkViewTheme.h"
#include "vtkViewUpdater.h"
#include "vtkGeoAssignCoordinates.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkGraphMapper.h"
#include "vtkEarthSource.h"
#include "vtkLookupTable.h"
#include "vtkMutableUndirectedGraph.h"
#include "vtkImageViewer2.h"
#include "vtkImageActor.h"
#include "vtkMath.h"
#include <vtkLegendScaleActor.h>
#include "vtkPointSetToLabelHierarchy.h"
#include "vtkIdTypeArray.h"
#include "vtkPolyData.h"
#include "vtkStdString.h"
#include <vtksys/ios/sstream>
#include <vtksys/SystemTools.hxx>
#include "ThreadedPlayer.h"


 /* Macro to create objects */
#define VTK_CREATE(type,name) \
vtkSmartPointer<type> name = vtkSmartPointer<type>::New();
 
// Constructor
SimpleView::SimpleView() 
{
	initializeVariables();
	this->ui = new Ui_SimpleView;
	this->ui->setupUi(this);
 
	/* Set up the signals and slots for all the different buttons/sliders/combo boxes. */
	connect(this->ui->actionExit, SIGNAL(triggered()), this, SLOT(slotExit()));
	connect(this->ui->baseColorDropDown, SIGNAL(currentIndexChanged(int)), this, SLOT(slotBaseColorSelected(int)));
	connect(this->ui->transparencySlider, SIGNAL(valueChanged(int)), this, SLOT(slotMapTransparencySliderMoved(int)));
	connect(this->ui->locationDropDown, SIGNAL(currentIndexChanged(int)), this, SLOT(slotMapLocationSelected(int)));
	connect(this->ui->resetViewButton, SIGNAL(pressed()), this, SLOT(slotResetView()));
	connect(this->ui->resetViewButton, SIGNAL(released()), this, SLOT(slotResetView()));
	connect(this->ui->depthScaleSlider, SIGNAL(valueChanged(int)), this, SLOT(slotDepthScaleSliderMoved(int)));
	connect(this->ui->maxDepthSlider, SIGNAL(valueChanged(int)), this, SLOT(slotMaxDepthSliderMoved(int)));
	connect(this->ui->minDepthSlider, SIGNAL(valueChanged(int)), this, SLOT(slotMinDepthSliderMoved(int)));
	connect(this->ui->maxMagnitudeSlider, SIGNAL(valueChanged(int)), this, SLOT(slotMaxMagnitudeSliderMoved(int)));
	connect(this->ui->minMagnitudeSlider, SIGNAL(valueChanged(int)), this, SLOT(slotMinMagnitudeSliderMoved(int)));
	connect(this->ui->startingYearSlider, SIGNAL(valueChanged(int)), this, SLOT(slotStartingYearSliderMoved(int)));
	connect(this->ui->endingYearSlider, SIGNAL(valueChanged(int)), this, SLOT(slotEndingYearSliderMoved(int)));
	connect(this->ui->timeScaleSlider, SIGNAL(valueChanged(int)), this, SLOT(slotTimeScaleSliderMoved(int)));
	connect(this->ui->yearsPerUpdateComboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(slotYearsPerUpdateChanged(int)));
	connect(this->ui->playButton, SIGNAL(clicked()), this, SLOT(slotPlayButtonPressed()));
	connect(this->ui->stopButton, SIGNAL(clicked()), this, SLOT(slotStopButtonPressed()));

	std::string inputFilename = "Data/AllDataFromExcel.csv"; // data must be in the executable directory
	//std::string inputFilename = "C:\\Users\\Paul\\Desktop\\AllDataFromExcel.csv";
	//std::string inputFilename = "C:\\Users\\Paul\\Desktop\\savedFromParaview.csv";

	/* Create a CSV file reader */
	vtkSmartPointer<vtkDelimitedTextReader> readerForCSV =
	vtkSmartPointer<vtkDelimitedTextReader>::New();
	readerForCSV->SetFileName(inputFilename.c_str());
	readerForCSV->DetectNumericColumnsOn();
	readerForCSV->SetFieldDelimiterCharacters(",");
	printf("Reading The Data File... \n");
	readerForCSV->Update();
 
	/* Get the CSV values and put them into a table */
	vtkSmartPointer<vtkTable> table = readerForCSV->GetOutput();
	
	/* store the original depth, magnitude, and year values in separate arrays so values are not lost when the viewable data changes */
	depthArray = vtkSmartPointer<vtkDoubleArray>::New();
	depthArray->SetName("depth");

	magnitudeArray = vtkSmartPointer<vtkDoubleArray>::New();
	magnitudeArray->SetName("magnitude");

	yearArray = vtkSmartPointer<vtkIntArray>::New();
	yearArray->SetName("year");


	vtkSmartPointer<vtkMutableDirectedGraph> g = vtkSmartPointer<vtkMutableDirectedGraph>::New();

	/* create the points data set and make it global since we will be changing the values when the user requests certain data */
	points = vtkSmartPointer<vtkPoints>::New();
	pointsOriginal = vtkSmartPointer<vtkPoints>::New();

	/* The values from the online earthquake data are in the range from -255 and 255
	 * To convert them to latitude longitude coordinates we need to multiply the points by
	 * the constant below called earthquakeRatio
	 */
	printf("Parsing %d Data Points...", table->GetNumberOfRows());
	double earthquakeRatio = 360/255.0;
	for(vtkIdType i = 0; i < table->GetNumberOfRows()-1; i++)
	{
		/* fill the table and the different arrays with the correct values */
		if(((table->GetValue(i,1)).ToDouble()) > .99 ){
			g->AddVertex();
			yearArray->InsertNextValue((table->GetValue(i,0)).ToInt());
			magnitudeArray->InsertNextValue((table->GetValue(i,1)).ToDouble());
			depthArray->InsertNextValue((table->GetValue(i,4)).ToDouble());
			points->InsertNextPoint((table->GetValue(i,3)).ToDouble()*earthquakeRatio, (table->GetValue(i,2)).ToDouble()*earthquakeRatio, (table->GetValue(i,4)).ToDouble());
			pointsOriginal->InsertNextPoint((table->GetValue(i,3)).ToDouble()*earthquakeRatio, (table->GetValue(i,2)).ToDouble()*earthquakeRatio, (table->GetValue(i,4)).ToDouble());
		}
	}

	/* create a poly data set and give it the points just read in from the table */
	vtkSmartPointer<vtkPolyData> polydataPoints = vtkSmartPointer<vtkPolyData>::New();
	polydataPoints->SetPoints(points);

	vtkSmartPointer<vtkVertexGlyphFilter> glyphFilter = vtkSmartPointer<vtkVertexGlyphFilter>::New();
	glyphFilter->SetInputConnection(polydataPoints->GetProducerPort());
	glyphFilter->Update();


	polydata = vtkSmartPointer<vtkPolyData>::New();
	polydata->ShallowCopy(glyphFilter->GetOutput());
  
	/* Adding Colors To The Points */
  
	vtkSmartPointer<vtkUnsignedCharArray> colors = vtkSmartPointer<vtkUnsignedCharArray>::New();
	colors->SetNumberOfComponents(3);
	colors->SetName ("Colors");
	setColorScale1(*colors, magnitudeArray);
	
 
	polydata->GetPointData()->SetScalars(colors);

	/* Colors Added */

	/* Map the polydata */  
	vtkSmartPointer<vtkPolyDataMapper> mapper = vtkSmartPointer<vtkPolyDataMapper>::New();
	mapper->SetInputConnection(polydata->GetProducerPort());
 
	/* Create an actor for the polydata */
	actorForPolyData = vtkSmartPointer<vtkActor>::New();
	actorForPolyData->SetMapper(mapper);
	actorForPolyData->GetProperty()->SetPointSize(2);
 

	/* Use the JPEG Reader to be able to place the map in the render window*/
	char* fname = "Data/FlatMap.jpg";
	vtkStdString imageFile = fname;
	vtkSmartPointer<vtkGeoAlignedImageRepresentation> imageRep = vtkSmartPointer<vtkGeoAlignedImageRepresentation>::New();
	vtkSmartPointer<vtkGeoSource> imageSource1;
	vtkGeoAlignedImageSource* alignedSource = vtkGeoAlignedImageSource::New();
	vtkSmartPointer<vtkJPEGReader> reader = vtkSmartPointer<vtkJPEGReader>::New();
	reader->SetFileName(imageFile.c_str());
	reader->Update();
	imageViewer = vtkImageViewer2::New();
	imageViewer->SetInput( reader->GetOutput() );
	alignedSource->SetImage(reader->GetOutput());
	imageSource1.TakeReference(alignedSource);
	imageSource1->Initialize();
	imageRep->SetSource(imageSource1);
	
	imageViewer2 = vtkImageViewer2::New();
	imageViewer2->SetInput( reader->GetOutput() );
	
	imageViewer3 = vtkImageViewer2::New();
	imageViewer3->SetInput( reader->GetOutput() );

  
	/* Set the center of the map in the center of the render window */
	imageViewer->GetImageActor()->SetPosition(-256, -128, -5);
	imageViewer->GetImageActor()->SetOpacity(.5);
	imageViewer2->GetImageActor()->SetPosition(-256, -128, -5);
	imageViewer2->GetImageActor()->SetOpacity(.5);
	imageViewer3->GetImageActor()->SetPosition(-256, -128, -5);
	imageViewer3->GetImageActor()->SetOpacity(.5);
	slotResetView();
	/* END JPEG READER FOR MAP */
  
 
	/* Add a very simple depth, longitude, and latitude legend using a line source and placing labels at the end points */
	/* depth line and labels, this and the other two labels is that its public so it can change when the use interacts with the wndows */
	double p0[3] = {256, 0.0, 0.0};
	double p1[3] = {256.0, 0.0, 700.0};
	/* Create the line and its endpoints */
	lineSource = vtkSmartPointer<vtkLineSource>::New();
	lineSource->SetPoint1(p0);
	lineSource->SetPoint2(p1);
	lineSource->Update();

	/* Create the labels */
	labels = vtkSmartPointer<vtkStringArray>::New();
	labels->SetNumberOfValues(2);
	labels->SetName("labels");
	labels->SetValue(1, "Max Depth 700 km");
	labels->SetValue(0, "Min Depth 0 km");
	lineSource->GetOutput()->GetPointData()->AddArray(labels);
  
	/* Set the priority of the labels incase they ever over lap */
	vtkSmartPointer<vtkIntArray> sizes = vtkSmartPointer<vtkIntArray>::New();
	sizes->SetNumberOfValues(2);
	sizes->SetName("sizes");
	sizes->SetValue(0, 2);
	sizes->SetValue(1, 1);
	lineSource->GetOutput()->GetPointData()->AddArray(sizes);
	vtkSmartPointer<vtkPointSetToLabelHierarchy> pointSetToLabelHierarchyFilter =
	vtkSmartPointer<vtkPointSetToLabelHierarchy>::New();
	pointSetToLabelHierarchyFilter->SetInputConnection(
	lineSource->GetOutputPort());
	pointSetToLabelHierarchyFilter->SetLabelArrayName("labels");
	pointSetToLabelHierarchyFilter->SetPriorityArrayName("sizes");
	pointSetToLabelHierarchyFilter->Update();
  
	/* Map the labels to the line source and add it to an actor */
	vtkSmartPointer<vtkLabelPlacementMapper> labelMapper = vtkSmartPointer<
	vtkLabelPlacementMapper>::New();
	labelMapper->SetInputConnection(
	pointSetToLabelHierarchyFilter->GetOutputPort());
	vtkSmartPointer<vtkActor2D> labelActor = vtkSmartPointer<vtkActor2D>::New();
	labelActor->SetMapper(labelMapper);
	
	/* Map the line source and add it to an actor */
	vtkSmartPointer<vtkPolyDataMapper> lineMapper = 
	vtkSmartPointer<vtkPolyDataMapper>::New();
	lineMapper->SetInputConnection(lineSource->GetOutputPort());
	vtkSmartPointer<vtkActor> lineActor = 
	vtkSmartPointer<vtkActor>::New();
	lineActor->SetMapper(lineMapper);
	lineActor->GetProperty()->SetLineWidth(2);

	/* longitude line and labels */
	/* Create the line and its endpoints */
	double p2[3] = {-256, -148.0, -5.0};
	double p3[3] = {256.0, -148.0, -5.0};

	vtkSmartPointer<vtkLineSource> longitudeLine = vtkSmartPointer<vtkLineSource>::New();
	longitudeLine->SetPoint1(p2);
	longitudeLine->SetPoint2(p3);
	longitudeLine->Update();

	/* Create the labels */
	vtkSmartPointer<vtkStringArray> longitudeLabels = vtkSmartPointer<vtkStringArray>::New();
	longitudeLabels->SetNumberOfValues(2);
	longitudeLabels->SetName("longitudeLabels");
	longitudeLabels->SetValue(1, "Longtidue: 180");
	longitudeLabels->SetValue(0, "Longitude: -180");
	longitudeLine->GetOutput()->GetPointData()->AddArray(longitudeLabels);
  
	/* Set the priority of the labels incase they ever over lap */
	longitudeLine->GetOutput()->GetPointData()->AddArray(sizes);
	vtkSmartPointer<vtkPointSetToLabelHierarchy> longitudeHierarchy =
	vtkSmartPointer<vtkPointSetToLabelHierarchy>::New();
	longitudeHierarchy->SetInputConnection(
	longitudeLine->GetOutputPort());
	longitudeHierarchy->SetLabelArrayName("longitudeLabels");
	longitudeHierarchy->SetPriorityArrayName("sizes");
	longitudeHierarchy->Update();
  
	/* Map the labels to the line source and add it to an actor */
	vtkSmartPointer<vtkLabelPlacementMapper> longitudeLabelMapper = vtkSmartPointer<
	vtkLabelPlacementMapper>::New();
	longitudeLabelMapper->SetInputConnection(
	longitudeHierarchy->GetOutputPort());
	vtkSmartPointer<vtkActor2D> longitudeLabelActor = vtkSmartPointer<vtkActor2D>::New();
	longitudeLabelActor->SetMapper(longitudeLabelMapper);
	
	/* Map the line source and add it to an actor */
	vtkSmartPointer<vtkPolyDataMapper> longitdueLineMapper = 
	vtkSmartPointer<vtkPolyDataMapper>::New();
	longitdueLineMapper->SetInputConnection(longitudeLine->GetOutputPort());
	vtkSmartPointer<vtkActor> longitudeLineActor = 
	vtkSmartPointer<vtkActor>::New();
	longitudeLineActor->SetMapper(longitdueLineMapper);
	longitudeLineActor->GetProperty()->SetLineWidth(2);


	/* latitude line and labels */
	/* Create the line and its endpoints */
	double p4[3] = {-276, -128, -5.0};
	double p5[3] = {-276.0, 128.0, -5.0};

	vtkSmartPointer<vtkLineSource> latitudeLine = vtkSmartPointer<vtkLineSource>::New();
	latitudeLine->SetPoint1(p4);
	latitudeLine->SetPoint2(p5);
	latitudeLine->Update();

	/* Create the labels */
	vtkSmartPointer<vtkStringArray> latitudeLabels = vtkSmartPointer<vtkStringArray>::New();
	latitudeLabels->SetNumberOfValues(2);
	latitudeLabels->SetName("latitudeLabels");
	latitudeLabels->SetValue(1, "Latitude: 90");
	latitudeLabels->SetValue(0, "Latitude: -90");
	latitudeLine->GetOutput()->GetPointData()->AddArray(latitudeLabels);
  
	/* Set the priority of the labels incase they ever over lap */
	latitudeLine->GetOutput()->GetPointData()->AddArray(sizes);
	vtkSmartPointer<vtkPointSetToLabelHierarchy> latitudeHierarchy =
	vtkSmartPointer<vtkPointSetToLabelHierarchy>::New();
	latitudeHierarchy->SetInputConnection(
	latitudeLine->GetOutputPort());
	latitudeHierarchy->SetLabelArrayName("latitudeLabels");
	latitudeHierarchy->SetPriorityArrayName("sizes");
	latitudeHierarchy->Update();
  
	/* Map the labels to the line source and add it to an actor */
	vtkSmartPointer<vtkLabelPlacementMapper> latitudeLabelMapper = vtkSmartPointer<
	vtkLabelPlacementMapper>::New();
	latitudeLabelMapper->SetInputConnection(
	latitudeHierarchy->GetOutputPort());
	vtkSmartPointer<vtkActor2D> latitudeLabelActor = vtkSmartPointer<vtkActor2D>::New();
	latitudeLabelActor->SetMapper(latitudeLabelMapper);
	
	/* Map the line source and add it to an actor */
	vtkSmartPointer<vtkPolyDataMapper> latitudeLineMapper = 
	vtkSmartPointer<vtkPolyDataMapper>::New();
	latitudeLineMapper->SetInputConnection(latitudeLine->GetOutputPort());
	vtkSmartPointer<vtkActor> latitudeLineActor = 
	vtkSmartPointer<vtkActor>::New();
	latitudeLineActor->SetMapper(latitudeLineMapper);
	latitudeLineActor->GetProperty()->SetLineWidth(2);
	/* Done adding the legend and labels */
 
	/* Create the magnitude color legend with QT based objects instead of VTK*/
	this->ui->colorScaleLabel->setPixmap(QPixmap("Red.jpg"));
	vtkSmartPointer<vtkRenderer> renderer = vtkSmartPointer<vtkRenderer>::New();
	vtkSmartPointer<vtkRenderWindow> renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
	renderWindow->AddRenderer(imageViewer->GetRenderer());
	vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor = vtkSmartPointer<vtkRenderWindowInteractor>::New();
	renderWindowInteractor->SetRenderWindow(renderWindow);
 
	/* add all the actors to all 3 render windows */
	imageViewer->GetRenderer()->AddActor(lineActor);
	imageViewer->GetRenderer()->AddActor(labelActor);
	imageViewer->GetRenderer()->AddActor(longitudeLineActor);
	imageViewer->GetRenderer()->AddActor(longitudeLabelActor);
	imageViewer->GetRenderer()->AddActor(latitudeLineActor);
	imageViewer->GetRenderer()->AddActor(latitudeLabelActor);
	imageViewer->GetRenderer()->AddActor(actorForPolyData);
	imageViewer->GetRenderer()->SetBackground(.1, .1, .1);  
	imageViewer->GetRenderer()->GetRenderWindow()->SetInteractor(ui->qvtkWidget->GetInteractor());

	
	imageViewer2->GetRenderer()->AddActor(lineActor);
	imageViewer2->GetRenderer()->AddActor(labelActor);
	imageViewer2->GetRenderer()->AddActor(longitudeLineActor);
	imageViewer2->GetRenderer()->AddActor(longitudeLabelActor);
	imageViewer2->GetRenderer()->AddActor(latitudeLineActor);
	imageViewer2->GetRenderer()->AddActor(latitudeLabelActor);
	imageViewer2->GetRenderer()->AddActor(actorForPolyData);
	imageViewer2->GetRenderer()->SetBackground(.1, .1, .1);  
	imageViewer2->GetRenderer()->GetRenderWindow()->SetInteractor(ui->qvtkWidget_2->GetInteractor());
	
	imageViewer3->GetRenderer()->AddActor(lineActor);
	imageViewer3->GetRenderer()->AddActor(labelActor);
	imageViewer3->GetRenderer()->AddActor(longitudeLineActor);
	imageViewer3->GetRenderer()->AddActor(longitudeLabelActor);
	imageViewer3->GetRenderer()->AddActor(latitudeLineActor);
	imageViewer3->GetRenderer()->AddActor(latitudeLabelActor);
	imageViewer3->GetRenderer()->AddActor(actorForPolyData);
	imageViewer3->GetRenderer()->SetBackground(.1, .1, .1);  
	imageViewer3->GetRenderer()->GetRenderWindow()->SetInteractor(ui->qvtkWidget_3->GetInteractor());

    this->ui->transparencySlider->setSliderPosition(30);
	slotDepthScaleSliderMoved(50);
	
	/* Pass the render window to the qt vtk render window */
	this->ui->qvtkWidget->SetRenderWindow(imageViewer->GetRenderer()->GetRenderWindow());
	this->ui->qvtkWidget_2->SetRenderWindow(imageViewer2->GetRenderer()->GetRenderWindow());
	this->ui->qvtkWidget_3->SetRenderWindow(imageViewer3->GetRenderer()->GetRenderWindow());
	imageSource1->ShutDown();
	alignedSource->ShutDown();
};

/* Initialize the original data set variables 
 * These are all values the user can change which is why they are global
 */
void SimpleView::initializeVariables(){
	depthPercent = 100;
	colorScheme = 0;
	maxDepth = 700;
	maxMagnitude = 10;
	minDepth = 0;
	minMagnitude = 0;
	startingYear = 1973;
	endingYear = 2011;
	updatesPerSecond = .5;
	yearsPerUpdate = 1;
	timeScale = 1;
	play = false;
	currentYear = 1973;
}

/* Set the points color scale to red */
void SimpleView::setColorScale1(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {depthValue,otherValue,otherValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}

/* Set the points color scale to green */
void SimpleView::setColorScale2(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {otherValue,depthValue,otherValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}


/* Set the points color scale to blue */
void SimpleView::setColorScale3(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {otherValue,otherValue,depthValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}

/* Set the points color scale to light blue */
void SimpleView::setColorScale4(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {otherValue,depthValue,255-depthValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}

/* Set the points color scale to yellow and green */
void SimpleView::setColorScale5(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {depthValue,255-depthValue,otherValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}

/* Set the points color scale to purple */
void SimpleView::setColorScale6(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {255-depthValue,otherValue,depthValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}

/* Set the points color scale to bright green */
void SimpleView::setColorScale7(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {otherValue,255-depthValue,depthValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}

/* Set the points color scale to orange and yellow */
void SimpleView::setColorScale8(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData){
	for(vtkIdType i = 0; i < arrayOfData->GetSize(); i++)
	{
		double depthValue = arrayOfData->GetValue(i);
		if(depthValue > 10){
			depthValue = 10;
		}
		double otherValue = getRGBScalar(depthValue);
		depthValue *= 25.5;
		unsigned char temp[3] = {255-depthValue,depthValue,otherValue};
		colorScalar.InsertNextTupleValue(temp);
	}
}

/* use customly selected rgb values to make the color scale much more visible */
double SimpleView::getRGBScalar(double depthValue){
	double otherValue = 0;
	if(depthValue < 2){
		otherValue = 0;
	} else if(depthValue < 2.5){
		otherValue = 1;
	} else if(depthValue < 3){
		otherValue = 1.5;
	} else if(depthValue < 3.5){
		otherValue = 3;
	} else if(depthValue < 4){
		otherValue = 5;
	} else if(depthValue < 4.5){
		otherValue = 7;
	} else if(depthValue < 5){
		otherValue = 9;
	} else if(depthValue < 5.5){
		otherValue = 11;
	} else if(depthValue < 6){
		otherValue = 14;
	} else if(depthValue < 6.5){
		otherValue = 17;
	} else if(depthValue > 7){
		otherValue = 20;
	} 
	otherValue *= 6.5;
	return otherValue;
}

/* slot to clean all the QT objects up */
void SimpleView::slotExit() 
{
  qApp->exit();
}

/* resets the view to the original position 
 * If the map is not viewable after pressing this button click and drag in the main window
 */
void SimpleView::slotResetView(){
	imageViewer->GetRenderer()->GetActiveCamera()->SetRoll(0);
	imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-.5,-800,450);
	imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(0,0,0);
	imageViewer->GetRenderer()->GetActiveCamera()->UpdateViewport(imageViewer->GetRenderer()); 
	this->ui->qvtkWidget->update();
	
	/* only update top right if the checkbox is checked */
	if(this->ui->topLeftViewCheckBox->isChecked()){
		imageViewer2->GetRenderer()->GetActiveCamera()->SetRoll(0);
		imageViewer2->GetRenderer()->GetActiveCamera()->SetPosition(-.5,-800,450);
		imageViewer2->GetRenderer()->GetActiveCamera()->SetFocalPoint(0,0,0);
		imageViewer2->GetRenderer()->GetActiveCamera()->UpdateViewport(imageViewer2->GetRenderer()); 
		this->ui->qvtkWidget_2->update();
	}
	
	/* only update bottom right if the checkbox is checked */
	if(this->ui->bottomRightViewCheckBox->isChecked()){
		imageViewer3->GetRenderer()->GetActiveCamera()->SetRoll(0);
		imageViewer3->GetRenderer()->GetActiveCamera()->SetPosition(-.5,-800,450);
		imageViewer3->GetRenderer()->GetActiveCamera()->SetFocalPoint(0,0,0);
		imageViewer3->GetRenderer()->GetActiveCamera()->UpdateViewport(imageViewer3->GetRenderer()); 
		this->ui->qvtkWidget_3->update();
	}
}

/* Set the view to the user specified map location from the map location combo box */
void SimpleView::slotMapLocationSelected(int indexValue){
	imageViewer->GetRenderer()->GetActiveCamera()->SetRoll(0);
	switch (indexValue){
		case 0:// Normal View
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-.5,-800,450);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(0,0,0); 
		break;
		case 1:// Bering Sea/Alaska
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-225.895,43.837,153.98);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(-214.88, 74.99, 46.175);  
		break;
		case 2://california
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-167.187,21.972,62.02);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(-165.30, 32.48, 39.925);
		break;	
		case 3:// Chile
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-107.837, -100.462, 52.581);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(-99.859, -11.24, -15.903);
		break;
		case 4://China/India
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(117.36,3.05,105.704);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(117.367, 38.27, 19.429);
		break;
		case 5:// Indonesia
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(155.57,-53.76,75.95);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(155.607, 0.353, 0.089); 
		break;
		case 6:// Hawaii
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-217.481,-28.82,68.25);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(-217.455, 20.622, 9.204);
		break;
		case 7:// Hungary
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(37.45, 23.464, 66.603);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(36.03, 42.944, 27.765); 
		break;
		case 8:// Japan
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(191.75, -20.97, 82.811);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(194.20, 23.795, 37.635);
		break;
		case 9:// Mid Atlantic Ridge
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-50.685, -72.406, 87.869);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(-46.340, 6.904, 7.837);
		break;
		case 10:// Puerto Rico
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(-93.349, 21.467, 85.039);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(-92.333, 22.72, 21.411);
		break;
		case 11:// Tonga (Southern Pacific)
			imageViewer->GetRenderer()->GetActiveCamera()->SetPosition(224.299, -129.097, 142.166);
			imageViewer->GetRenderer()->GetActiveCamera()->SetFocalPoint(221.175, -13.099, -20.429);
		break;
	}
	imageViewer->GetRenderer()->GetActiveCamera()->UpdateViewport(imageViewer->GetRenderer());  
	this->ui->qvtkWidget->update();
}

/* Set the map transparency */
void SimpleView::slotMapTransparencySliderMoved(int value){
	double transparency = value/100.0;
	imageViewer->GetImageActor()->SetOpacity(transparency);
	imageViewer2->GetImageActor()->SetOpacity(transparency);
	imageViewer3->GetImageActor()->SetOpacity(transparency);
	this->ui->qvtkWidget->update();
	/* only update top right if the checkbox is checked */
	if(this->ui->topLeftViewCheckBox->isChecked()){
		this->ui->qvtkWidget_2->update();
	}
	/* only update bottom right if the checkbox is checked */
	if(this->ui->bottomRightViewCheckBox->isChecked()){
		this->ui->qvtkWidget_3->update();
	}
}

/* change the color scheme based on the base color combo box value */
void SimpleView::slotBaseColorSelected(int indexValue){
	colorScheme = indexValue;
	redrawScene();
}

/* Handles the depth scale slider changes */
void SimpleView::slotDepthScaleSliderMoved(int value){
	depthPercent = value;
	char percent[4];
	itoa(depthPercent,percent,10);
	QString text(QString((const char*)percent) + QString("%"));
	this->ui->depthScaleTextBox->setText(text);
	redrawScene();
}

/* Handles the maximum depth slider changes */
void SimpleView::slotMaxDepthSliderMoved(int value){
	maxDepth = value * 7;
	if(minDepth > maxDepth){
		minDepth = maxDepth;
		this->ui->minDepthSlider->setSliderPosition(value);
	}
	setDepthTextBox();
	redrawScene();
}

/* Handles the minimum depth slider changes */
void SimpleView::slotMinDepthSliderMoved(int value){
	minDepth = value*7;
	if(minDepth > maxDepth){
		maxDepth = minDepth;
		this->ui->maxDepthSlider->setSliderPosition(value);
	}
	setDepthTextBox();
	redrawScene();
}

/* Handles the maximum magnitude slider changes */
void SimpleView::slotMaxMagnitudeSliderMoved(int value){
	maxMagnitude = value/10.0;
	if(maxMagnitude < 1){
		maxMagnitude = 1;
	}
	if(minMagnitude > maxMagnitude){
		minMagnitude = maxMagnitude;
		this->ui->minMagnitudeSlider->setSliderPosition((int)(maxMagnitude*10));
	}
	setMagnitudeTextBox();
	redrawScene();
}

/* Handles the minimum magnitude slider changes */
void SimpleView::slotMinMagnitudeSliderMoved(int value){
	minMagnitude = value/10.0;
	if(minMagnitude < 1){
		minMagnitude = 1;
	}
	if(minMagnitude > maxMagnitude){
		maxMagnitude = minMagnitude;
		this->ui->maxMagnitudeSlider->setSliderPosition((int)(minMagnitude*10));
	}
	setMagnitudeTextBox();
	redrawScene();
}

/* Handles the starting year slider changes */
void SimpleView::slotStartingYearSliderMoved(int value){
	startingYear = value;
	if(startingYear > endingYear){
		endingYear = startingYear;
		this->ui->endingYearSlider->setSliderPosition(value);
	}
	setYearTextBoxes();
	redrawScene();
}

/* Handles the ending year slider changes */
void SimpleView::slotEndingYearSliderMoved(int value){
	endingYear = value;
	if(startingYear > endingYear){
		startingYear = endingYear;
		this->ui->startingYearSlider->setSliderPosition(value);
	}
	setYearTextBoxes();
	redrawScene();
}

/* Converts the starting and ending year integer values to strings and set the starting and ending year text box values */
void SimpleView::setYearTextBoxes(){
	char startBuf[4];
	itoa(startingYear, startBuf, 10);
	QString startText((const char*)startBuf);
	char endBuf[4];
	if(endingYear > 2011){
		endingYear = 2011;
	}
	itoa(endingYear, endBuf, 10);
	QString endText((const char*)endBuf);
	this->ui->startingYearTextBox->setText(startText);
	this->ui->endingYearTextBox->setText(endText);
}

/* Converts the depth integer values to strings and sets the depth text box value */
void SimpleView::setDepthTextBox(){
	char minBuf[3];
	itoa(minDepth,minBuf,10);
	char maxBuf[3];
	itoa(maxDepth,maxBuf,10);
	QString text(QString((const char*)minBuf) + QString("-") + QString((const char*)maxBuf));
	this->ui->depthTextBox->setText(text);
}

/* Converts the double values to strings and sets the magnitude text box value */
void SimpleView::setMagnitudeTextBox(){
	std::string min, max;
	{
	std::ostringstream mins, maxs;
	mins << minMagnitude;
	min = mins.str();
	maxs << maxMagnitude;
	max = maxs.str();
	}
	QString text(QString(min.c_str()) + QString('-') + QString(max.c_str()));
	this->ui->magnitudeTextBox->setText(text);
}

/* Handles the play back speed slider changes */
void SimpleView::slotTimeScaleSliderMoved(int value){
	timeScale = value/100.0;
	std::string timeScaleString;
	{
		std::ostringstream value;
		value << timeScale;
		timeScaleString = value.str();
	}
	this->ui->timeScaleTextBox->setText(QString(timeScaleString.c_str()));
}


/* Handles the years per update combo box changes */
void SimpleView::slotYearsPerUpdateChanged(int value){
	yearsPerUpdate = value+1;
}

/* Creates a new thread that controls the playback speed when the user hits the play button 
 * Having the timer threaded allows the user to still interact with the view
 * The user can still change colors, min/max values, camera position, and depth scale
*/
void SimpleView::slotPlayButtonPressed(){
	this->ui->playButton->setEnabled(false);
	this->ui->startingYearSlider->setEnabled(false);
	this->ui->endingYearSlider->setEnabled(false);
	currentYear = startingYear;
	ThreadedPlayer *p = new ThreadedPlayer();
	int yearSpan = endingYear - startingYear; /* calculate number of years to play back */
	int numberOfUpdates = yearSpan/yearsPerUpdate; /* calculate number of updates per play back */
	if(yearSpan%yearsPerUpdate != 0){ /* if the number of updates isn't a whole number add 1 extra update cycle */
		numberOfUpdates += 1;
	}
	/* Connect the threads signal updateView() to the main thread's slot called slotupdateDataSet().
	 * This allows the QThread to send messages to the main vtk render loop without causing data corruption
	 * Without it, the QThread would call draw when the data is being changed and the program would 
	 * crash due to reading corrupted data.
	 */
	connect(p, SIGNAL(updateView()), this, SLOT(slotUpdateDataSet())); 
	/* Connect the main classes stop button to the thread's slot called slotStopPlaying() which sets play to false in the thread */
	connect(this->ui->stopButton, SIGNAL(clicked()), p, SLOT(slotStopPlaying()));
	/* Connect the threads signal doneUpdating() to the main thread's slot slotDoneUpdating() to enable the play button */
	connect(p, SIGNAL(doneUpdating()), this, SLOT(slotDoneUpdating()));
	p->setTimeInterval(timeScale, numberOfUpdates); 
	p->start();
}

/* When the timer thread is complete, it lets the main thread know so it can enable the play button and year sliders */
void SimpleView::slotDoneUpdating(){
	this->ui->playButton->setEnabled(true);
	this->ui->startingYearSlider->setEnabled(true);
	this->ui->endingYearSlider->setEnabled(true);
}

/* When the stop button is pressed, enable the play button and year sliders */
void SimpleView::slotStopButtonPressed(){
	this->ui->playButton->setEnabled(true);
	this->ui->startingYearSlider->setEnabled(true);
	this->ui->endingYearSlider->setEnabled(true);
}

/* slot called from the threaded timer that updates the dataset to the specified years */
void SimpleView::slotUpdateDataSet(){
	currentYear += yearsPerUpdate;
	startingYear = currentYear;
	this->ui->startingYearSlider->setSliderPosition(startingYear);
	endingYear = currentYear + yearsPerUpdate;
	this->ui->endingYearSlider->setSliderPosition(endingYear);
	setYearTextBoxes();
	if(endingYear < 2013){
		redrawScene();
	}
}

/* redraws the scene with the correct data set */
void SimpleView::redrawScene(){	
	/* Create the new set of points based on the user changed values such as min/max depth, min/max magnitude, and starting/ending years */
	vtkSmartPointer<vtkPoints> newPoints = vtkSmartPointer<vtkPoints>::New();
	double depthP = depthPercent/100.0;
	vtkSmartPointer<vtkDoubleArray> magArray = vtkSmartPointer<vtkDoubleArray>::New();
	magArray->SetName("mag");
	for(vtkIdType i = 0; i < points->GetNumberOfPoints(); i++)
	{
		/* make sure each point drawn is within the correct user specified values */
		if(depthArray->GetValue(i) <= maxDepth && depthArray->GetValue(i) >= minDepth && magnitudeArray->GetValue(i) <= maxMagnitude && magnitudeArray->GetValue(i) >= minMagnitude && yearArray->GetValue(i) >= startingYear && yearArray->GetValue(i) <= endingYear){
			double* tempPoint = pointsOriginal->GetPoint(i);
			magArray->InsertNextValue(magnitudeArray->GetValue(i));
			points->SetPoint(i, tempPoint[0], tempPoint[1], depthArray->GetValue(i)*depthP);
		} else { /* if its not put it somewhere far away, I do this because if I don't I received corrupted data errors because VTK was still trying to access points that I removed from the dataset */
			magArray->InsertNextValue(1);
			points->SetPoint(i, -1000, - 1000, 10);
		}
	}
	/* Reset the depth line to the correct minimum and maximum depth
	 * The reason for adding 1 to the max and subtracing 1 from the minimum is so they never equal each other
	 * If they do the labels for the line are no longer being set in the correct place and move all
	 * over the vtk render window
	 */
	double p1[3] = {256, 0, minDepth*depthP + 1};
	double p2[3] = {256, 0, maxDepth*depthP - 1};
	lineSource->SetPoint1(p1);
	lineSource->SetPoint2(p2);
	std::string min, max;
	{
	std::ostringstream mins, maxs;
	mins << minDepth;
	min = mins.str();
	maxs << maxDepth;
	max = maxs.str();
	}
	/* Set the string values of the labels */
	labels->SetValue(1, "Max Depth " + max + "km");
	labels->SetValue(0, "Min Depth " + min + "km");
		
	/* Adding Colors To The Points */
	vtkSmartPointer<vtkUnsignedCharArray> colors = vtkSmartPointer<vtkUnsignedCharArray>::New();
	colors->SetNumberOfComponents(3);
	colors->SetName ("Colors");
	if(colorScheme == 0){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/Red.jpg"));
		setColorScale1(*colors, magArray);
	} else if(colorScheme == 1){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/Green.jpg"));
		setColorScale2(*colors, magArray);
	} else if(colorScheme == 2){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/Blue.jpg"));
		setColorScale3(*colors, magArray);
	} else if(colorScheme == 3){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/BlueGreen.jpg"));
		setColorScale4(*colors, magArray);
	} else if(colorScheme == 4){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/GreenYellow.jpg"));
		setColorScale5(*colors, magArray);
	} else if(colorScheme == 5){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/PurpleBlue.jpg"));
		setColorScale6(*colors, magArray);
	} else if(colorScheme == 6){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/GreenPurple.jpg"));
		setColorScale7(*colors, magArray);
	} else if(colorScheme == 7){
		this->ui->colorScaleLabel->setPixmap(QPixmap("Data/OrangeGreen.jpg"));
		setColorScale8(*colors, magArray);
	}
	polydata->GetPointData()->SetScalars(colors);
	
	/* specifically tell the render window to update within the QT window */
	this->ui->qvtkWidget->update();
	/* only update top right window if the checkbox is checked */
	if(this->ui->topLeftViewCheckBox->isChecked()){
		this->ui->qvtkWidget_2->update();
	}
	/* only update bottom right window if the checkbox is checked */
	if(this->ui->bottomRightViewCheckBox->isChecked()){
		this->ui->qvtkWidget_3->update();
	}
}

