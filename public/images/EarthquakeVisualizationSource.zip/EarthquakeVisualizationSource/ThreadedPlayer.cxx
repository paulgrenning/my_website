#include "ThreadedPlayer.h"

/* empty constructor */
ThreadedPlayer::ThreadedPlayer(){
	
}

/* Sets the timer's update intervale and number of updates it needs to cycle through */
void ThreadedPlayer::setTimeInterval(double durationBetweenUpdate, int numberOfUpdates){
	timeInterval = durationBetweenUpdate;
	updates = numberOfUpdates;
}

/* slot that gets connected to the main thread to let the timer know it should stop */
void ThreadedPlayer::slotStopPlaying(){
	play = false;
}

/* launches the separate thread and sends signals to the main thread to let it know when its supposed to update the renderer */
void ThreadedPlayer::run(){
	play = true;
	vtkSmartPointer<vtkTimerLog> timer = vtkSmartPointer<vtkTimerLog>::New();
	double startTime = timer->GetUniversalTime();
	double nextUpdateTime = timer->GetUniversalTime() + timeInterval;
	double duration = timeInterval*(updates);
	while(startTime + duration > timer->GetUniversalTime() && play){
		if(nextUpdateTime < timer->GetUniversalTime()){
			nextUpdateTime = timer->GetUniversalTime() + timeInterval;
			emit updateView(); // emit the update signal
		}
	}
	emit doneUpdating(); // emits doneUpdating so the play button gets enabled and year sliders 
}