#ifndef SimpleViewUI_H
#define SimpleViewUI_H
 
#include "vtkSmartPointer.h"
#include <QMainWindow>
#include <vtkDoubleArray.h>
#include "vtkUnsignedCharArray.h"
#include "vtkIntArray.h"
#include "vtkPoints.h"
#include "vtkPolyData.h"
#include "vtkActor.h"
#include "vtkImageViewer2.h"
#include <qgraphicsproxywidget.h>
#include <qgraphicsscene.h>
#include "vtkLineSource.h"
#include "vtkStringArray.h"
#include "vtkLabelPlacementMapper.h"
#include "vtkActor2D.h"

// Forward Qt class declarations
class Ui_SimpleView;
 
class SimpleView : public QMainWindow
{
  Q_OBJECT
public:
 
  // Constructor/Destructor
  SimpleView();  
  void setColorScale1(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setColorScale2(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setColorScale3(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setColorScale4(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setColorScale5(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setColorScale6(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setColorScale7(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setColorScale8(vtkUnsignedCharArray &colorScalar, vtkDoubleArray *arrayOfData);
  void setDepthTextBox();
  void setMagnitudeTextBox();
  void setYearTextBoxes();
  void redrawScene();
  void initializeVariables();
  double getRGBScalar(double depthValue);
  ~SimpleView() {};
 
public slots:
 
  virtual void slotExit();
  virtual void slotResetView();
  virtual void slotMapLocationSelected(int indexValue);
  virtual void slotMapTransparencySliderMoved(int value);
  virtual void slotBaseColorSelected(int indexValue);
  virtual void slotDepthScaleSliderMoved(int value);
  virtual void slotMaxDepthSliderMoved(int value);
  virtual void slotMaxMagnitudeSliderMoved(int value);
  virtual void slotMinDepthSliderMoved(int value);
  virtual void slotMinMagnitudeSliderMoved(int value);
  virtual void slotStartingYearSliderMoved(int value);
  virtual void slotEndingYearSliderMoved(int value);
  virtual void slotTimeScaleSliderMoved(int value);
  virtual void slotPlayButtonPressed();
  virtual void slotYearsPerUpdateChanged(int value);
  virtual void slotUpdateDataSet();
  virtual void slotStopButtonPressed();
  virtual void slotDoneUpdating();
 
protected:
 
protected slots:
 
private:
 
	vtkSmartPointer<vtkDoubleArray> depthArray;
	vtkSmartPointer<vtkDoubleArray> magnitudeArray;
	vtkSmartPointer<vtkIntArray> yearArray;
	vtkSmartPointer<vtkPolyData> polydata;
	vtkSmartPointer<vtkLineSource> lineSource; 

	vtkImageViewer2* imageViewer;
	vtkImageViewer2* imageViewer2;
	vtkImageViewer2* imageViewer3;
	vtkSmartPointer<vtkPoints> points;
	vtkSmartPointer<vtkPoints> pointsOriginal;
	//vtkSmartPointer<vtkPolyData> polydataPoints;
	vtkSmartPointer<vtkActor> actorForPolyData;
	vtkSmartPointer<vtkStringArray> labels;
	
	QGraphicsProxyWidget* sceneWidget;
	int depthPercent;
	int colorScheme;
	int maxDepth;
	double maxMagnitude;
	int minDepth;
	double minMagnitude;
	int startingYear;
	int endingYear;
	int updatesPerSecond;
	int yearsPerUpdate;
	int currentYear;
	double timeScale;
	bool play;
  // Designer form
  Ui_SimpleView *ui;
};
 
#endif // SimpleViewUI_H